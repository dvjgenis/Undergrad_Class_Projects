# Evaluation user studies — statistical analysis

Python notebooks and tooling for the **Building AI for Music** questionnaire study (within-subject comparison of **System A** vs **System B**).

## Quick start

1. Use Python 3.10+ and a virtual environment.
2. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

3. Put the Google Forms CSV export in this directory (the filename is set in the first code cell of [`StatAnalysis.ipynb`](StatAnalysis.ipynb)).
4. Open [`StatAnalysis.ipynb`](StatAnalysis.ipynb) in Jupyter, VS Code, or Cursor and **run all cells from top to bottom** so definitions such as `construct_columns` and `a_to_b_col` stay in scope.

The notebook begins with a **table of contents** (linked to each section). Markdown cells before each code block explain that step’s role in the pipeline.

## Repository layout

| Item | Role |
|------|------|
| [`StatAnalysis.ipynb`](StatAnalysis.ipynb) | End-to-end workflow: load CSV, clean Likert/NPS fields, z-score items, split by system, Cronbach’s α, EFA (System A only), Shapiro–Wilk, paired tests with FDR correction, effect sizes |
| [`requirements.txt`](requirements.txt) | Pinned minimum versions for reproducibility |

## Analysis overview

- **Scaling:** Each survey item is **z-scored** across participants (before building composites) so mixed scales (1–7, 1–5, NPS-style) are on a common metric.
- **Reliability:** **Cronbach’s α** (via pingouin) is computed for predefined construct groupings on z-scored items.
- **EFA:** Exploratory factor analysis uses **System A** responses only so the same participant is not entered twice (A and B stacked).
- **Inference:** Construct-level **paired** comparisons (paired *t* or Wilcoxon signed-rank, chosen from composite normality checks) with **Benjamini–Hochberg FDR** across the construct-level tests.
- **Effect sizes:** **Cohen’s dz** for paired *t*; **rank correlation r** for Wilcoxon (see the effect-size section in the notebook).

For section-by-section narrative and code, use the table of contents at the top of [`StatAnalysis.ipynb`](StatAnalysis.ipynb).
